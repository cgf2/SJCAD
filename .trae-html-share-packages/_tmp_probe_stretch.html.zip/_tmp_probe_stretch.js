(function () {
  'use strict';
  var out = [];
  function log(msg) { out.push(msg); }
  try {
    log('CADApp=' + !!window.CADApp);
    log('model=' + !!(window.CADApp && window.CADApp.model));
    log('Tools=' + !!window.CADTools);
    var stretch = window.CADTools ? window.CADTools.byId('stretch') : null;
    log('stretch=' + !!stretch);
    var App = window.CADApp;
    App.model.clear();
    App.model.selected.clear();
    App.params.stp = true;
    App.params.sdd = 30;
    App.params.sept = 'end';
    var line = App.model.add({ type: 'line', p1: { x: 0, y: 0 }, p2: { x: 100, y: 0 } });
    App.model.selected.add(line.id);
    stretch.activate();
    stretch.applyParams();
    log('OK p2=' + line.p2.x + ',' + line.p2.y + ' len=' + Math.hypot(line.p2.x - line.p1.x, line.p2.y - line.p1.y));
  } catch (e) {
    log('ERR: ' + (e && e.message) + '\n' + (e && e.stack || '').split('\n').slice(0, 8).join('\n'));
  }
  var pre = document.createElement('pre');
  pre.id = 'probeResult';
  pre.textContent = out.join('\n');
  document.body.appendChild(pre);
})();
